import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gettingstarted',
  templateUrl: './gettingstarted.component.html',
  styleUrls: ['./gettingstarted.component.css']
})
export class GettingStartedComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
