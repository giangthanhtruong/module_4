/*
 * Public API Surface of ngx-audio-player
 */

export * from './lib/component/ngx-audio-player/ngx-audio-player.component';
export * from './lib/ngx-audio-player.module';
export * from './lib/model/track.model';
